//
//  AppDelegate.h
//  MVTranslateDemo
//
//  Created by LiYang on 2017/11/26.
//  Copyright © 2017年 LiYang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

