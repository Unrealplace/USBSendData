//
//  ViewController.h
//  MVTranslateDemo
//
//  Created by LiYang on 2017/11/26.
//  Copyright © 2017年 LiYang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

