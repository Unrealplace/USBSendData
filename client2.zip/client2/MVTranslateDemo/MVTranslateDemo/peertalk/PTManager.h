//
//  PTManager.h
//  Peertalk Example
//
//  Created by LiYang on 2017/11/27.
//

#import <Foundation/Foundation.h>
#import "PTChannel.h"

@protocol PTManagerDelegate <NSObject>

@optional

- (BOOL)peertalkShouldAcceptDataOfType:(UInt32)type;

- (void)peertalkDidReceiveData:(NSData*)data ofType:(UInt32)type;

- (void)peertalkDidChangeConnection:(BOOL)connected;


@end


@interface PTManager : NSObject

@property (nonatomic, weak) id   <PTManagerDelegate> delegate;

@property (nonatomic, assign) int    portNumber;

@property (nonatomic, assign) BOOL    isConnected;

@property (nonatomic, strong) PTChannel    *serverChannel;

@property (nonatomic, strong) PTChannel    *peerChannel;

+ (instancetype)shared;

- (void)connectWithPortNumber:(int)portNum;

- (void)disConnect;


- (void)sendDataWith:(NSData*)data type:(int)type andCompletionHander:(void(^)(BOOL success ))compleationHandler;

- (void)sendObjectWith:(id) data type:(int)type andCompletionHander:(void(^)(BOOL success ))compleationHandler;

@end
