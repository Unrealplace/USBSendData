//
//  PTManager.m
//  Peertalk Example
//
//  Created by LiYang on 2017/11/27.
//

#import "PTManager.h"
#import "PTProtocol.h"

@interface NSData (extension)
- (id)convert;
- (dispatch_data_t)createReferencingDispatchData;
+ (NSData*)toDataWith:(id)object;
@end

@implementation NSData
- (id)convert{
    return [NSKeyedUnarchiver unarchiveObjectWithData:self];
}
+ (NSData*)toDataWith:(id)object{
    return [NSKeyedArchiver archivedDataWithRootObject:object];
}
- (dispatch_data_t)createReferencingDispatchData {
    // Note: The queue is used to submit the destructor. Since we only perform an
    // atomic release of self, it doesn't really matter which queue is used, thus
    // we use the current calling queue.
    return dispatch_data_create((const void*)self.bytes, self.length, dispatch_get_main_queue(), ^{
        // trick to have the block capture the data, thus retain/releasing
        [self length];
    });
}
//- (nonnull id)copyWithZone:(nullable NSZone *)zone {
//    <#code#>
//}
//
//- (nonnull id)mutableCopyWithZone:(nullable NSZone *)zone {
//    <#code#>
//}
//
//- (void)encodeWithCoder:(nonnull NSCoder *)aCoder {
//    <#code#>
//}
//
//- (nullable instancetype)initWithCoder:(nonnull NSCoder *)aDecoder { 
//    <#code#>
//}

@end

@interface PTManager()<PTChannelDelegate>

@end

@implementation PTManager

+ (instancetype)shared{
    static PTManager * manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[PTManager alloc] init];
    });
    return manager;
}

- (void)connectWithPortNumber:(int)portNum{
    if (!_isConnected) {
        self.portNumber = portNum;
        PTChannel * channel = [PTChannel channelWithDelegate:self];
        [channel listenOnPort:portNum IPv4Address:INADDR_LOOPBACK callback:^(NSError *error) {
            if (!error) {
                self.serverChannel = channel;
            }
        }];
    }
}
- (BOOL)isConnected{
    return _peerChannel != nil;
}
- (void)disConnect{
    [self.serverChannel close];
    [self.peerChannel close];
    _serverChannel = nil;
    _peerChannel    = nil;
    
}
- (void)sendDataWith:(NSData *)data type:(int)type andCompletionHander:(void (^)(BOOL))compleationHandler{
    
    if (_peerChannel) {
        [_peerChannel sendFrameOfType:type tag:PTFrameNoTag withPayload:[self getdispatchdataWith:data] callback:^(NSError *error) {
            if (!error) {
                compleationHandler(YES);
            }else{
                compleationHandler(NO);
            }
        }];
    }
    
}
- (dispatch_data_t)getdispatchdataWith:(NSData*)data{
    return dispatch_data_create((const void*)data.bytes, data.length, dispatch_get_main_queue(), ^{
        // trick to have the block capture the data, thus retain/releasing
        [data length];
    });
}
- (void)sendObjectWith:(id)data type:(int)type andCompletionHander:(void (^)(BOOL))compleationHandler{
    
    NSData * newdata = [NSData toDataWith:data];
    if (_peerChannel != nil) {
        [_peerChannel sendFrameOfType:type tag:PTFrameNoTag withPayload:[newdata createReferencingDispatchData] callback:^(NSError *error) {
            if (!error) {
                compleationHandler(YES);
            }else{
                compleationHandler(NO);
            }
        }];
        
    }
}

#pragma PTChannel 代理方法
// Invoked when a new frame has arrived on a channel.
- (void)ioFrameChannel:(PTChannel*)channel didReceiveFrameOfType:(uint32_t)type tag:(uint32_t)tag payload:(PTData*)payload{
    
    dispatch_data_t dispatchData = [payload dispatchData];
    NSData * data = [NSData dataWithContentsOfDispatchData:dispatchData];
    [self.delegate peertalkDidReceiveData:data ofType:type];
    
}

// Invoked to accept an incoming frame on a channel. Reply NO ignore the
// incoming frame. If not implemented by the delegate, all frames are accepted.
- (BOOL)ioFrameChannel:(PTChannel*)channel shouldAcceptFrameOfType:(uint32_t)type tag:(uint32_t)tag payloadSize:(uint32_t)payloadSize{
    
    if (channel != _peerChannel) {
        return NO;
    }
    else{
        return [self.delegate peertalkShouldAcceptDataOfType:type];
    }
    
}

// Invoked when the channel closed. If it closed because of an error, *error* is
// a non-nil NSError object.
- (void)ioFrameChannel:(PTChannel*)channel didEndWithError:(NSError*)error{
    
    NSLog(@"ERROR (Connection ended) %@",error);
    _peerChannel = nil;
    _serverChannel = nil;
    [self.delegate peertalkDidChangeConnection:NO];
    
}

// For listening channels, this method is invoked when a new connection has been
// accepted.
- (void)ioFrameChannel:(PTChannel*)channel didAcceptConnection:(PTChannel*)otherChannel fromAddress:(PTAddress*)address{
    if (_peerChannel != nil) {
        [_peerChannel cancel];
    }
    _peerChannel = otherChannel;
    _peerChannel.userInfo = address;
    NSLog(@"SUCCESS (Connected to channel)");
    [self.delegate peertalkDidChangeConnection:YES];
    
    
}


@end
