//
//  ACUDPServerManager.h
//  MVTranslateDemo
//
//  Created by LiYang on 2017/11/26.
//  Copyright © 2017年 LiYang. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^ACUDPServerReceiveDataBlock)(NSData * data,NSError * error);


@interface ACUDPServerManager : NSObject
- (void)startUDPServerWithPort:(uint16_t)port;
- (void)sendBroadCast;
- (void)sendCommandAndRecieveData:(ACUDPServerReceiveDataBlock) udpServerReceiveDataBlock;
@end
