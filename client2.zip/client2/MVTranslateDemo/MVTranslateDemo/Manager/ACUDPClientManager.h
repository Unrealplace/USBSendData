//
//  ACUDPClientManager.h
//  MVTranslateDemo
//
//  Created by LiYang on 2017/11/26.
//  Copyright © 2017年 LiYang. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum :NSInteger{
    ACUDPSendDataCodeSuccess = 0,
    ACUDPSendDataCodeFailed,
    ACUDPSendDataCodeUnkonw
}ACUDPSendDataCode;

typedef void (^ACUDPClientRecieverDataBlock)(NSData * data,NSError*error);
typedef void (^ACUDPClientSendDataBlock)(ACUDPSendDataCode stateCode,NSError*error);

@interface ACUDPClientManager : NSObject

@property (nonatomic, assign) uint16_t     udpPort;
@property (nonatomic, copy) NSString    * host;
@property (nonatomic, assign) BOOL         udpConnect;

+ (instancetype)sharedManager;

- (void)closeUDPClient;

- (BOOL)startUDPClient;

- (void)sendData:(NSData*)sourceData withSendDataStateBlock:(ACUDPClientSendDataBlock)sendDataBlock andRecieverDataHandler:(ACUDPClientRecieverDataBlock)receiverDataBlock;

@end
