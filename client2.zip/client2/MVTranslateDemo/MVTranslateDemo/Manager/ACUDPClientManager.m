//
//  ACUDPClientManager.m
//  MVTranslateDemo
//
//  Created by LiYang on 2017/11/26.
//  Copyright © 2017年 LiYang. All rights reserved.
//

#import "ACUDPClientManager.h"
#import "ACAsyncSocket.h"
#import "ACAsyncUdpSocket.h"

const int CLIENT_PORT = 15656;
const int UDP_SENDDATA_TAG  = 200;
@interface ACUDPClientManager()<ACAsyncUdpSocketDelegate>{
    ACUDPClientRecieverDataBlock  revDataBlock;
    ACUDPClientSendDataBlock       sndDataBlock;
}
@property (nonatomic, strong) ACAsyncUdpSocket   * udpClicent;

@end;

@implementation ACUDPClientManager

+ (instancetype)sharedManager{
    static ACUDPClientManager * manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[ACUDPClientManager alloc] init];
    });
    return manager;
    
}
- (BOOL)startUDPClient{
    BOOL bindResult = NO;
    NSError * error;
    [self closeUDPClient];
    if (_udpClicent == nil) {
        _udpClicent = [[ACAsyncUdpSocket alloc] initWithDelegate:self delegateQueue:dispatch_queue_create("com.ACUDPClientManager.queue", NULL)];
        bindResult   = [_udpClicent bindToPort:CLIENT_PORT error:&error];
        if (error) {
            NSLog(@"bind error---->%@",error);
        }
        [_udpClicent beginReceiving:nil];
    }else{
        return YES;
    }
    return bindResult;
   
}

- (void)closeUDPClient{
    [_udpClicent close];
    _udpClicent.delegate = nil;
    _udpClicent                = nil;
    _udpConnect              = NO;
    
}
- (void)sendData:(NSData *)sourceData withSendDataStateBlock:(ACUDPClientSendDataBlock)sendDataBlock andRecieverDataHandler:(ACUDPClientRecieverDataBlock)receiverDataBlock{
  
    @try{
        if (revDataBlock == nil) {
            revDataBlock  = receiverDataBlock;
        }
        if (sndDataBlock == nil) {
            sndDataBlock = sendDataBlock;
        }
        if (sourceData == nil || sourceData.length == 0) {
            
            NSError * sendError = [NSError errorWithDomain:@"com.sendDataError" code:ACUDPSendDataCodeFailed userInfo:@{}];
            sndDataBlock(ACUDPSendDataCodeFailed,sendError);
            return;
        }
        NSData * newData = [sourceData subdataWithRange:NSMakeRange(0, 512)];

        [_udpClicent sendData:newData toHost:_host port:_udpPort withTimeout:10 tag:UDP_SENDDATA_TAG];
        
    }@catch (NSException * e){
        NSLog(@"exception---->%@",e);
    }@finally{
        
    }
}

#pragma mark udpsocket delegate;
- (void)udpSocket:(ACAsyncUdpSocket *)sock didConnectToAddress:(NSData *)address{
    self.udpConnect = YES;
}
- (void)udpSocket:(ACAsyncUdpSocket *)sock didNotConnect:(NSError * _Nullable)error{
    
    if (revDataBlock) {
        revDataBlock(nil,error);
    }
    self.udpConnect = NO;
}

- (void)udpSocket:(ACAsyncUdpSocket *)sock didSendDataWithTag:(long)tag{
    
    if (tag == UDP_SENDDATA_TAG) {
        if (sndDataBlock) {
            sndDataBlock(ACUDPSendDataCodeSuccess,nil);
        }
    }
}

- (void)udpSocket:(ACAsyncUdpSocket *)sock
didNotSendDataWithTag:(long)tag
       dueToError:(NSError * _Nullable)error{
    if (tag == UDP_SENDDATA_TAG) {
        NSLog(@"client发送失败-->%@",error);
        if (sndDataBlock) {
            sndDataBlock(ACUDPSendDataCodeFailed,error);
        }
    }
}


- (void)udpSocket:(ACAsyncUdpSocket *)sock
   didReceiveData:(NSData *)data
      fromAddress:(NSData *)address
withFilterContext:(nullable id)filterContext{
    
    self.host       = [ACAsyncUdpSocket hostFromAddress:address];
    self.udpPort = [ACAsyncUdpSocket portFromAddress:address];
    if ([self.host hasPrefix:@"::"])return;
    NSLog(@"receiver---->from--->ip:%@and---port:%d",self.host,self.udpPort);
    self.udpConnect = YES;
}

- (void)udpSocketDidClose:(ACAsyncUdpSocket *)sock
                withError:(NSError  * _Nullable)error{
    
    NSLog(@"clientClose error--->>>%@",error);
    if (sndDataBlock) {
        sndDataBlock(ACUDPSendDataCodeUnkonw,error);
    }
    self.udpConnect = NO;
    
}


@end
